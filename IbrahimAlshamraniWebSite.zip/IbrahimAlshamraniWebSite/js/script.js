document.addEventListener('DOMContentLoaded', function () {
  // زر الصفحة الرئيسية
  var heroBtn = document.getElementById('heroBtn');
  if (heroBtn) {
    heroBtn.addEventListener('click', function () {
      alert('تم الضغط على الزر');
      var heroMsg = document.getElementById('heroMsg');
      if (heroMsg) {
        heroMsg.textContent = 'JavaScript يعمل بنجاح ✅';
        heroMsg.style.color = 'green';
      }
    });
  }

  // نموذج التواصل في صفحة contact.html
  var form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var name = document.getElementById('name').value.trim();
      var email = document.getElementById('email').value.trim();
      var message = document.getElementById('message').value.trim();
      var result = document.getElementById('formResult');

      if (!result) return;

      if (!name || !email || !message) {
        result.textContent = 'يرجى تعبئة جميع الحقول';
        result.style.color = 'red';
        return;
      }

      var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        result.textContent = 'بريد غير صحيح';
        result.style.color = 'red';
        return;
      }

      result.textContent = 'تم الإرسال بنجاح';
      result.style.color = 'green';
      form.reset();
    });
  }
});
